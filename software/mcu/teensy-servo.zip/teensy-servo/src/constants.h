#ifndef CONSTANTS_H
#define CONSTANTS_H
#include <Arduino.h>
namespace COMM
{
  constexpr uint32_t BAUD_RATE = 921600;
  constexpr uint8_t  CS_SDCARD = BUILTIN_SDCARD;
}






#endif