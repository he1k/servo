#include "storage.h"

// Empty constructor
Storage::Storage()
{

}
// Initialize the Storage object.
// Returns true if connection to SD card was estabilshed, otherwise false
bool Storage::begin(uint8_t cs)
{
  cs_sd = cs;
  for(uint32_t i = 0; i < STORAGE::BFR_SIZE; i++)
  {
    bfr[i] = 0;
  }
  bfr_idx = 0;
  curr_file = nullptr;
  bool sd_init = SD.sdfs.begin(SdioConfig(FIFO_SDIO));//SD.begin(cs_sd);
  state = sd_init ? STORAGE::STATE::IDLE : STORAGE::STATE::ERROR;
  return sd_init;
}
uint8_t Storage::read_clear_error()
{
  uint8_t err = state;
  state = STORAGE::STATE::IDLE;
  return err;
}

// Returns true if a file at path exists, otherwise false
bool Storage::file_exists(const String& path)
{
  return SD.exists(path.c_str());
}

// Returns true if a file at path was created, otherwise false
bool Storage::create_file(const String& path)
{
  // Check if other operation or error is present
  if(state != STORAGE::STATE::IDLE)
  {
    Serial.println("ERR: Not in idle mode");
    state = STORAGE::STATE::ERROR;
    return false;
  }
  // Check if file already exists
  if(file_exists(path))
  {
    Serial.println("ERR: File already exists");
    state = STORAGE::STATE::ERROR;
    return false;
  }
  // Create the file
  curr_file = SD.open(path.c_str(), FILE_WRITE);
  if(curr_file)
  {
    curr_file.close();
    return true;
  }else
  {
    Serial.println("ERR: Couldn't create file");
    state = STORAGE::STATE::ERROR;
    return false;
  }
}

// Returns true if file at path was opened successfully for reading, otherwise false
bool Storage::open_file_read(const String& path)
{
  // Check if other operation or error is present
  if(state != STORAGE::STATE::IDLE)
  {
    Serial.println("ERR: Not in idle mode");
    state = STORAGE::STATE::ERROR;
    return false;
  }
  // Check if file exists
  if(!file_exists(path))
  {
    Serial.println("ERR: File does not exist");
    state = STORAGE::STATE::ERROR;
    return false;
  }
  curr_file = SD.open(path.c_str(), FILE_READ);
  if(!curr_file)
  {
    Serial.println("ERR: Opening file for reading failed");
    state = STORAGE::STATE::ERROR;
    return false;
  }
  state = STORAGE::STATE::READING;
  return true;
}
bool Storage::open_file_write(const String& path)
{
  // Check if other operation or error is present
  if(state != STORAGE::STATE::IDLE)
  {
    Serial.println("ERR: Not in idle mode");
    state = STORAGE::STATE::ERROR;
    return false;
  }
  // Check if file exists
  if(!file_exists(path))
  {
    Serial.println("ERR: File does not exist");
    state = STORAGE::STATE::ERROR;
    return false;
  }
  curr_file = SD.open(path.c_str(), FILE_WRITE);
  if(!curr_file)
  {
    Serial.println("ERR: Opening file for writing failed");
    state = STORAGE::STATE::ERROR;
    return false;
  }
  state = STORAGE::STATE::WRITING;
  return true;
}
bool Storage::write_line_to_file(const String& line)
{
  if(state == STORAGE::STATE::WRITING)
  {
    curr_file.println(line);
    return true;
  }else
  {
    Serial.println("ERR: No file opened for writing");
    state = STORAGE::STATE::ERROR;
    return false;
  }
}


void Storage::list_all_files(const String& path, int depth) {
  File dir = SD.open(path.c_str());
  if (!dir || !dir.isDirectory())
  {
    Serial.println("Not a directory or does not exist.");
    return;
  }
  File file;
  while ((file = dir.openNextFile()))
  {
    for (int i = 0; i < depth; i++)
    {
      Serial.print("  "); // Indent for subdirectories
    }

    if (file.isDirectory())
    {
      Serial.print("[DIR] ");
      Serial.println(file.name());
      // Recursive call to list files in the subdirectory
      list_all_files(file.name(), depth + 1);
    }
    else
    {
      Serial.print("[FILE] ");
      Serial.print(file.name());
      Serial.print("  SIZE: ");
      Serial.println(file.size());
    }
    file.close();
  }
}
void Storage::close_file()
{
  curr_file.close();
}