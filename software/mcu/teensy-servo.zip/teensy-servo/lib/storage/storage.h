#ifndef STORAGE_H
#define STORAGE_H
#include <Arduino.h>
#include <SD.h>
#include <SPI.h>

namespace STORAGE
{
  constexpr uint8_t CS_SDCARD = BUILTIN_SDCARD;
  constexpr uint16_t BFR_SIZE = 512;
  namespace STATE
  {
    constexpr uint8_t IDLE = 0;    // Idling
    constexpr uint8_t READING = 1; // Reading file
    constexpr uint8_t WRITING = 2; // Writing file
    constexpr uint8_t ERROR = 3;   // Error
  }
}

class Storage
{
  private:
    uint8_t cs_sd; // CS for SD card reader
    uint32_t bfr_idx;
    uint8_t state;
    File curr_file; // Current file
  public:
    uint8_t bfr[STORAGE::BFR_SIZE];
    /**
     * Empty constructor
     */
    Storage();
    /**
     * Initialize the object. 
     * \param cs is the chip select pin for the SD card
     * \returns result of communication establishment with SD card
     */
    bool begin(uint8_t cs);
    /**
     * Prints the whole file tree
     * \param path is the path to the file
     * \param depth used for formatting subdirectories
     * \returns void
     */
    void list_all_files(const String& path, int depth = 0);
    /**
     * Check if file with path exists
     * \param path is the path to the file
     * \returns if the file exists on the SD card.
     */
    bool file_exists(const String& path);
    /**
     * Create a new file with path
     * \param path is the path to the file
     * \returns if the file was created
     * \note can return false due to multiple reasons
     */
    bool create_file(const String& path);
    /**
     * Open file at path for reading only
     * \param path is the path to the file
     * \returns if the file was opened for reading successfully 
     * \note can return false due to multiple reasons
     */
    bool open_file_read(const String& path);
    /**
     * Open file at path for writing only
     * \param path is the path to the file
     * \returns if the file was opened for writing successfully 
     * \note can return false due to multiple reasons
     */
    bool open_file_write(const String& path);
    /**
     * Writes a line (string) 
     * \param line is the path to the file
     * \returns if the line was written to the file
     * \note there is no need path provided, as this
     *       function assumes there is already a file
     *       opened for writing (curr_file) determinde
     *       by the state
     */
    bool write_line_to_file(const String& line);
    /**
     * Reads and clears the error state
     * \returns the error
     * \note this sets the state to idle again
     */
    uint8_t read_clear_error();
    /**
     * Closes the current file
     * \returns none
     */
    void close_file();

    
};



#endif